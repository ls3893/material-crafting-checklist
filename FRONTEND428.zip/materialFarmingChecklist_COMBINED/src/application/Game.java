package application;

import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileReader;

public class Game
{
	public static HashMap<String, ArrayList<String>> Minecraft(String category)
	{
		String csvFile = "src/allcrafting-mc.csv";
		
		ArrayList<String> list = new ArrayList<>();
		list = readWithBR(csvFile);
				
		HashMap<String, ArrayList<String>> basic = new HashMap<>();
		HashMap<String, ArrayList<String>> block = new HashMap<>();
		HashMap<String, ArrayList<String>> tool = new HashMap<>();
		HashMap<String, ArrayList<String>> defense = new HashMap<>();
		HashMap<String, ArrayList<String>> mechanism = new HashMap<>();
		HashMap<String, ArrayList<String>> food = new HashMap<>();
		HashMap<String, ArrayList<String>> other = new HashMap<>();
		HashMap<String, ArrayList<String>> dye = new HashMap<>();
		HashMap<String, ArrayList<String>> wool = new HashMap<>();
		HashMap<String, ArrayList<String>> brewing = new HashMap<>();
		
		for(int i = 0; i < list.size(); i++)
		{
			if(list.get(i).contains("Basic_"))
			{
				String list1 = list.get(i);
				String[] array1 = list1.split(",");
				
				ArrayList<String> arrayList1 = new ArrayList<>();
				
				for(int j = 0; j < array1.length-2; j++)
					arrayList1.add(array1[2+j].toString());
				
				basic.put(array1[1], arrayList1);
			}
			else if(list.get(i).contains("Block_"))
			{
				String list2 = list.get(i);
				String[] array2 = list2.split(",");
				
				ArrayList<String> arrayList2 = new ArrayList<>();
				
				for(int j = 0; j < array2.length-2; j++)
					arrayList2.add(array2[2+j].toString());
				
				block.put(array2[1], arrayList2);
			}
			else if(list.get(i).contains("Tool_"))
			{
				String list3 = list.get(i);
				String[] array3 = list3.split(",");
				
				ArrayList<String> arrayList3 = new ArrayList<>();
				
				for(int j = 0; j < array3.length-2; j++)
					arrayList3.add(array3[2+j].toString());
				
				tool.put(array3[1], arrayList3);
			}
			else if(list.get(i).contains("Defense_"))
			{
				String list4 = list.get(i);
				String[] array4 = list4.split(",");
				
				ArrayList<String> arrayList4 = new ArrayList<>();
				
				for(int j = 0; j < array4.length-2; j++)
					arrayList4.add(array4[2+j].toString());
				
				defense.put(array4[1], arrayList4);
			}
			else if(list.get(i).contains("Mechanism_"))
			{
				String list5 = list.get(i);
				String[] array5 = list5.split(",");
				
				ArrayList<String> arrayList5 = new ArrayList<>();
				
				for(int j = 0; j < array5.length-2; j++)
					arrayList5.add(array5[2+j].toString());
				
				mechanism.put(array5[1], arrayList5);
			}
			else if(list.get(i).contains("Food_"))
			{
				String list6 = list.get(i);
				String[] array6 = list6.split(",");
				
				ArrayList<String> arrayList6 = new ArrayList<>();
				
				for(int j = 0; j < array6.length-2; j++)
					arrayList6.add(array6[2+j].toString());
				
				food.put(array6[1], arrayList6);
			}
			else if(list.get(i).contains("Other_"))
			{
				String list7 = list.get(i);
				String[] array7 = list7.split(",");
				
				ArrayList<String> arrayList7 = new ArrayList<>();
				
				for(int j = 0; j < array7.length-2; j++)
					arrayList7.add(array7[2+j].toString());
				
				other.put(array7[1], arrayList7);
			}
			else if(list.get(i).contains("Dye_"))
			{
				String list8 = list.get(i);
				String[] array8 = list8.split(",");
				
				ArrayList<String> arrayList8 = new ArrayList<>();
				
				for(int j = 0; j < array8.length-2; j++)
					arrayList8.add(array8[2+j].toString());
				
				dye.put(array8[1], arrayList8);
			}
			else if(list.get(i).contains("Wool_"))
			{
				String list9 = list.get(i);
				String[] array9 = list9.split(",");
				
				ArrayList<String> arrayList9 = new ArrayList<>();
				
				for(int j = 0; j < array9.length-2; j++)
					arrayList9.add(array9[2+j].toString());
				
				wool.put(array9[1], arrayList9);
			}
			else if(list.get(i).contains("Brewing_"))
			{
				String list10 = list.get(i);
				String[] array10 = list10.split(",");
				
				ArrayList<String> arrayList10 = new ArrayList<>();
				
				for(int j = 0; j < array10.length-2; j++)
					arrayList10.add(array10[2+j].toString());
				
				brewing.put(array10[1], arrayList10);
			}
		}
		
		if(category.equals("Basic"))
		{
			return basic;
		}
		else if(category.equals("Block"))
		{
			return block;
		}
		else if(category.equals("Tool"))
		{
			return tool;
		}
		else if(category.equals("Defense"))
		{
			return defense;
		}
		else if(category.equals("Mechanism"))
		{
			return mechanism;
		}
		else if(category.equals("Food"))
		{
			return food;
		}
		else if(category.equals("Other"))
		{
			return other;
		}
		else if(category.equals("Dye"))
		{
			return dye;
		}
		else if(category.equals("Wool"))
		{
			return wool;
		}
		else if(category.equals("Brewing"))
		{
			return brewing;
		}
		else
			return null;
	}
	
	public static HashMap<String, ArrayList<String>> StardewValley(String category)
	{
		String csvFile = "src/allcrafting-sdv.csv";
		
		
		ArrayList<String> list = new ArrayList<>();
		list = readWithBR(csvFile);
		
		HashMap<String, ArrayList<String>> bombs = new HashMap<>();
		HashMap<String, ArrayList<String>> fences = new HashMap<>();
		HashMap<String, ArrayList<String>> sprinklers = new HashMap<>();
		HashMap<String, ArrayList<String>> artisanEquipment = new HashMap<>();
		HashMap<String, ArrayList<String>> fertilizer = new HashMap<>();
		HashMap<String, ArrayList<String>> seeds = new HashMap<>();
		HashMap<String, ArrayList<String>> decor = new HashMap<>();
		HashMap<String, ArrayList<String>> fishing = new HashMap<>();
		HashMap<String, ArrayList<String>> rings = new HashMap<>();
		HashMap<String, ArrayList<String>> edibleItems = new HashMap<>();
		HashMap<String, ArrayList<String>> consumables = new HashMap<>();
		HashMap<String, ArrayList<String>> lighting = new HashMap<>();
		HashMap<String, ArrayList<String>> refiningEquipment = new HashMap<>();
		HashMap<String, ArrayList<String>> furniture = new HashMap<>();
		HashMap<String, ArrayList<String>> storageEquipment = new HashMap<>();
		HashMap<String, ArrayList<String>> signs = new HashMap<>();
		HashMap<String, ArrayList<String>> misc = new HashMap<>();
		
		
		for(int i = 0; i < list.size(); i++)
		{
			if(list.get(i).contains("Bombs_"))
			{
				String list1 = list.get(i);
				String[] array1 = list1.split(",");
				
				ArrayList<String> arrayList1 = new ArrayList<>();
				
				for(int j = 0; j < array1.length-2; j++)
					arrayList1.add(array1[2+j].toString());
				
				bombs.put(array1[1], arrayList1);
			}
			else if(list.get(i).contains("Fences_"))
			{
				String list2 = list.get(i);
				String[] array2 = list2.split(",");
				
				ArrayList<String> arrayList2 = new ArrayList<>();
				
				for(int j = 0; j < array2.length-2; j++)
					arrayList2.add(array2[2+j].toString());
				
				fences.put(array2[1], arrayList2);
			}
			else if(list.get(i).contains("Sprinklers_"))
			{
				String list3 = list.get(i);
				String[] array3 = list3.split(",");
				
				ArrayList<String> arrayList3 = new ArrayList<>();
				
				for(int j = 0; j < array3.length-2; j++)
					arrayList3.add(array3[2+j].toString());
				
				sprinklers.put(array3[1], arrayList3);
			}
			else if(list.get(i).contains("Artisan Equipment_"))
			{
				String list4 = list.get(i);
				String[] array4 = list4.split(",");
				
				ArrayList<String> arrayList4 = new ArrayList<>();
				
				for(int j = 0; j < array4.length-2; j++)
					arrayList4.add(array4[2+j].toString());
				
				artisanEquipment.put(array4[1], arrayList4);
			}
			else if(list.get(i).contains("Fertilizer_"))
			{
				String list5 = list.get(i);
				String[] array5 = list5.split(",");
				
				ArrayList<String> arrayList5 = new ArrayList<>();
				
				for(int j = 0; j < array5.length-2; j++)
					arrayList5.add(array5[2+j].toString());
				
				fertilizer.put(array5[1], arrayList5);
			}
			else if(list.get(i).contains("Seeds_"))
			{
				String list6 = list.get(i);
				String[] array6 = list6.split(",");
				
				ArrayList<String> arrayList6 = new ArrayList<>();
				
				for(int j = 0; j < array6.length-2; j++)
					arrayList6.add(array6[2+j].toString());
				
				seeds.put(array6[1], arrayList6);
			}
			else if(list.get(i).contains("Decor_"))
			{
				String list7 = list.get(i);
				String[] array7 = list7.split(",");
				
				ArrayList<String> arrayList7 = new ArrayList<>();
				
				for(int j = 0; j < array7.length-2; j++)
					arrayList7.add(array7[2+j].toString());
				
				decor.put(array7[1], arrayList7);
			}
			else if(list.get(i).contains("Fishing_"))
			{
				String list8 = list.get(i);
				String[] array8 = list8.split(",");
				
				ArrayList<String> arrayList8 = new ArrayList<>();
				
				for(int j = 0; j < array8.length-2; j++)
					arrayList8.add(array8[2+j].toString());
				
				fishing.put(array8[1], arrayList8);
			}
			else if(list.get(i).contains("Rings_"))
			{
				String list9 = list.get(i);
				String[] array9 = list9.split(",");
				
				ArrayList<String> arrayList9 = new ArrayList<>();
				
				for(int j = 0; j < array9.length-2; j++)
					arrayList9.add(array9[2+j].toString());
				
				rings.put(array9[1], arrayList9);
			}
			else if(list.get(i).contains("Edible Items_"))
			{
				String list10 = list.get(i);
				String[] array10 = list10.split(",");
				
				ArrayList<String> arrayList10 = new ArrayList<>();
				
				for(int j = 0; j < array10.length-2; j++)
					arrayList10.add(array10[2+j].toString());
				
				edibleItems.put(array10[1], arrayList10);
			}
			else if(list.get(i).contains("Consumables_"))
			{
				String list11 = list.get(i);
				String[] array11 = list11.split(",");
				
				ArrayList<String> arrayList11 = new ArrayList<>();
				
				for(int j = 0; j < array11.length-2; j++)
					arrayList11.add(array11[2+j].toString());
				
				consumables.put(array11[1], arrayList11);
			}
			else if(list.get(i).contains("Lighting_"))
			{
				String list12 = list.get(i);
				String[] array12 = list12.split(",");
				
				ArrayList<String> arrayList12 = new ArrayList<>();
				
				for(int j = 0; j < array12.length-2; j++)
					arrayList12.add(array12[2+j].toString());
				
				lighting.put(array12[1], arrayList12);
			}
			else if(list.get(i).contains("Refining Equipment_"))
			{
				String list13 = list.get(i);
				String[] array13 = list13.split(",");
				
				ArrayList<String> arrayList13 = new ArrayList<>();
				
				for(int j = 0; j < array13.length-2; j++)
					arrayList13.add(array13[2+j].toString());
				
				refiningEquipment.put(array13[1], arrayList13);
			}
			else if(list.get(i).contains("Furniture_"))
			{
				String list14 = list.get(i);
				String[] array14 = list14.split(",");
				
				ArrayList<String> arrayList14 = new ArrayList<>();
				
				for(int j = 0; j < array14.length-2; j++)
					arrayList14.add(array14[2+j].toString());
				
				furniture.put(array14[1], arrayList14);
			}
			else if(list.get(i).contains("Storage Equipment_"))
			{
				String list15 = list.get(i);
				String[] array15 = list15.split(",");
				
				ArrayList<String> arrayList15 = new ArrayList<>();
				
				for(int j = 0; j < array15.length-2; j++)
					arrayList15.add(array15[2+j].toString());
				
				storageEquipment.put(array15[1], arrayList15);
			}
			else if(list.get(i).contains("Signs_"))
			{
				String list16 = list.get(i);
				String[] array16 = list16.split(",");
				
				ArrayList<String> arrayList16 = new ArrayList<>();
				
				for(int j = 0; j < array16.length-2; j++)
					arrayList16.add(array16[2+j].toString());
				
				signs.put(array16[1], arrayList16);
			}
			else if(list.get(i).contains("Misc_"))
			{
				String list17 = list.get(i);
				String[] array17 = list17.split(",");
				
				ArrayList<String> arrayList17 = new ArrayList<>();
				
				for(int j = 0; j < array17.length-2; j++)
					arrayList17.add(array17[2+j].toString());
				
				misc.put(array17[1], arrayList17);
			}
			
		}
		
		if(category.equals("Bombs"))
		{
			return bombs;
		}
		else if(category.equals("Fences"))
		{
			return fences;
		}
		else if(category.equals("Sprinklers"))
		{
			return sprinklers;
		}
		else if(category.equals("Artisan Equipment"))
		{
			return artisanEquipment;
		}
		else if(category.equals("Fertilizer"))
		{
			return fertilizer;
		}
		else if(category.equals("Seeds"))
		{
			return seeds;
		}
		else if (category.equals("Decor"))
		{
			return decor;
		}
		else if(category.equals("Fishing"))
		{
			return fishing;
		}
		else if(category.equals("Rings"))
		{
			return rings;
		}
		else if(category.equals("Edible Items"))
		{
			return edibleItems;
		}
		else if(category.equals("Consumables"))
		{
			return consumables;
		}
		else if(category.equals("Lighting"))
		{
			return lighting;
		}
		else if(category.equals("Refining Equipment"))
		{
			return refiningEquipment;
		}
		else if(category.equals("Furniture"))
		{
			return furniture;
		}
		else if(category.equals("Storage Equipment"))
		{
			return storageEquipment;
		}
		else if(category.equals("Signs"))
		{
			return signs;
		}
		else if(category.equals("Misc"))
		{
			return misc;
		}
		else
		{
			return null;
		}
		
	}
	
	public static Map<String, ArrayList<String>> sorting(ArrayList<String> list, int i)
	{
		String string = list.get(i);
		String[] array = string.split(",");
			
		ArrayList<String> arrayList = new ArrayList<>();
			
		for(int j = 0; j < array.length-2; j++)
			arrayList.add(array[2+j].toString());
			
		Map<String, ArrayList<String>> entry = new HashMap<>();
			
		entry.put(array[1], arrayList);
			
		return entry;
	}
	
	public static ArrayList<String> readWithBR(String csvFile) throws UnsupportedOperationException
	{
		ArrayList<String> list = new ArrayList<>();
		
		try(BufferedReader reader = new BufferedReader(new FileReader(csvFile)))
		{
			String line;
			while((line = reader.readLine()) != null)
			{
				list.add(line);
			}
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
		}
		
		return list;
	}

}
