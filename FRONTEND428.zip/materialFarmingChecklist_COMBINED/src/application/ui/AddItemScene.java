package application.ui;

import application.Item;
import application.ui.ItemChecklist;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.util.List;

public class AddItemScene
{
    public Scene createAddItemScene(Stage primaryStage, String gameName, List<String> categories, String cssFilePath) 
    {
        Item item = new Item();
        item.setGame(gameName);

        Label title = new Label(gameName + " Add Item");
        HBox titleForm = new HBox(title);
        titleForm.setAlignment(Pos.CENTER);
        titleForm.setId("mine-header");

        Label categoryLabel = new Label("Category:");
        ComboBox<String> categoryDrop = new ComboBox<>();
        categoryDrop.getItems().addAll(categories);
        categoryDrop.setPromptText("Select one");

        Label itemLabel = new Label("Item:");
        ComboBox<String> itemDrop = new ComboBox<>();
        itemDrop.setPromptText("Select one");

        Label xLabel = new Label(" x ");
        TextField quantityText = new TextField();
        quantityText.setPromptText("Quantity");

        Button addItemButton = new Button("Add Item");

        categoryDrop.setOnAction(e -> 
        {
            String selectedCategory = categoryDrop.getValue();
            item.setCategory(selectedCategory);

            itemDrop.getItems().clear();
            List<String> itemsInCategory = item.displayIDs(); 
            itemDrop.getItems().addAll(itemsInCategory);
        });


        itemDrop.setOnAction(e -> 
        {
            String selectedItem = itemDrop.getValue();
            item.setID(selectedItem);
        });

        addItemButton.setOnAction(e -> 
        {
            try 
            {
                int quantity = Integer.parseInt(quantityText.getText());
                if (quantity <= 0) 
                {
                    return;
                }

                Item newItem = new Item();
                newItem.setGame(gameName);
                newItem.setCategory(categoryDrop.getValue());
                newItem.setID(itemDrop.getValue());
                newItem.setQuantity(quantity);
                newItem.updatedRecipeQuantities();

                if ("Minecraft".equals(gameName)) 
                {
                    ChecklistSelection.customMinecraftItems.add(newItem); 
                    ItemChecklist itemChecklistScene = new ItemChecklist();
                    Scene mineChecklistScene = itemChecklistScene.mineItemCheck(primaryStage);
                    primaryStage.setScene(mineChecklistScene);

                } 
                else if ("Stardew Valley".equals(gameName)) 
                {
                	ChecklistSelection.customStardewItems.add(newItem);
                    ItemChecklist itemChecklistScene = new ItemChecklist();
                    Scene stardewChecklistScene = itemChecklistScene.stardewItemCheck(primaryStage);
                    System.out.println("New Stardew item added: " + newItem.getID() + " x" + quantity);
                    primaryStage.setScene(stardewChecklistScene);

                }

    
            } 
            catch (NumberFormatException ex) 
            {
            	
            }
        });

        HBox categoryForm = new HBox(10, categoryLabel, categoryDrop);
        HBox itemForm = new HBox(10, itemLabel, itemDrop, xLabel, quantityText);
        HBox buttonForm = new HBox(addItemButton);
        buttonForm.setAlignment(Pos.CENTER);

        VBox layout = new VBox(15, titleForm, categoryForm, itemForm, buttonForm);
        layout.setPadding(new Insets(20));

        Scene scene = new Scene(layout, 600, 400);
        scene.getStylesheets().add(AddItemScene.class.getResource(cssFilePath).toExternalForm());
        return scene;
    }
}

