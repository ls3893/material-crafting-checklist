package application.ui;

import java.util.List;
import java.util.Map;

import application.Item;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ItemChecklist
{
    public Scene mineItemCheck(Stage primaryStage) 
    {
    	
    	VBox layout = new VBox(10);

        List<Item> items = application.ui.ChecklistSelection.customMinecraftItems;

        for (Item customItem : items) 
        {
            Text mineTitle = new Text("Craft: " + customItem.getID());  
            CheckBox itemCheckBox = new CheckBox(customItem.getID());
            VBox rawMaterialsBox = new VBox(10);

            customItem.setID(customItem.getID());
            Map<String, Integer> requiredMaterials = customItem.updatedRecipeQuantities();

            for (Map.Entry<String, Integer> entry : requiredMaterials.entrySet()) 
            {
                String materialName = entry.getKey();
                int requiredAmount = entry.getValue();

                Text materialText = new Text(materialName); 
                Spinner<Integer> quantitySpinner = new Spinner<>();
                quantitySpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, requiredAmount, requiredAmount));
                quantitySpinner.setPrefWidth(80);

                quantitySpinner.valueProperty().addListener((obs, oldValue, newValue) -> 
                {
                    materialText.setStrikethrough(newValue == 0);
                });

                HBox materialRow = new HBox(10, materialText, quantitySpinner);
                rawMaterialsBox.getChildren().add(materialRow);
            }
            
            Button toChecklistSelect = new Button("View Checklists");
            toChecklistSelect.setOnAction(e ->
            {
            	ChecklistSelection toChecklistSelection = new ChecklistSelection();
            	Scene nextScene = toChecklistSelection.chooseGameList(primaryStage); 
            	primaryStage.setScene(nextScene);

            });


            VBox itemBox = new VBox(10, mineTitle, itemCheckBox, rawMaterialsBox); // ADD TITLE
            itemBox.setPadding(new Insets(10));
            itemBox.setStyle("-fx-border-color: gray; -fx-border-width: 1; -fx-border-radius: 5;");
            layout.getChildren().add(itemBox);

            break; 
        }
        Button toChecklistSelect = new Button("View Checklists");
        toChecklistSelect.setOnAction(e ->
        {
            ChecklistSelection toChecklistSelection = new ChecklistSelection();
            Scene nextScene = toChecklistSelection.chooseGameList(primaryStage); 
            primaryStage.setScene(nextScene);
        });
        
        HBox toChecklistButton = new HBox(toChecklistSelect);
        toChecklistButton.setPadding(new Insets(10));
        toChecklistButton.setSpacing(10);
        layout.getChildren().add(toChecklistButton);

        ScrollPane scrollPane = new ScrollPane(layout);
        scrollPane.setFitToWidth(true);
        return new Scene(scrollPane, 600, 400);
        
        
        
    }

    public Scene stardewItemCheck(Stage primaryStage) 
    {
        VBox layout = new VBox(10);

        List<Item> items = application.ui.ChecklistSelection.customStardewItems;

        for (Item customItem : items) 
        {
            Text stardewTitle = new Text("Craft: " + customItem.getID());
            CheckBox itemCheckBox = new CheckBox(customItem.getID());
            VBox rawMaterialsBox = new VBox(5);

            customItem.setID(customItem.getID());
            Map<String, Integer> requiredMaterials = customItem.updatedRecipeQuantities();

            for (Map.Entry<String, Integer> entry : requiredMaterials.entrySet()) 
            {
                String materialName = entry.getKey();
                int requiredAmount = entry.getValue();

                Text materialText = new Text(materialName);
                Spinner<Integer> quantitySpinner = new Spinner<>();
                quantitySpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, requiredAmount, requiredAmount));
                quantitySpinner.setPrefWidth(80);

                quantitySpinner.valueProperty().addListener((obs, oldValue, newValue) -> 
                {
                    materialText.setStrikethrough(newValue == 0);
                });

                HBox materialRow = new HBox(10, materialText, quantitySpinner);
                rawMaterialsBox.getChildren().add(materialRow);
            }

            VBox itemBox = new VBox(10, stardewTitle, itemCheckBox, rawMaterialsBox); 
            itemBox.setPadding(new Insets(10));
            itemBox.setStyle("-fx-border-color: gray; -fx-border-width: 1; -fx-border-radius: 5;");
            layout.getChildren().add(itemBox);

            break;  
        }
        
        Button toChecklistSelect = new Button("View Checklists");
        toChecklistSelect.setOnAction(e ->
        {
            ChecklistSelection toChecklistSelection = new ChecklistSelection();
            Scene nextScene = toChecklistSelection.chooseGameList(primaryStage); 
            primaryStage.setScene(nextScene);
        });
        
        HBox toChecklistButton = new HBox(toChecklistSelect);
        toChecklistButton.setPadding(new Insets(10));
        toChecklistButton.setSpacing(10);
        layout.getChildren().add(toChecklistButton);

        ScrollPane scrollPane = new ScrollPane(layout);
        scrollPane.setFitToWidth(true);
        return new Scene(scrollPane, 600, 400);
    }
    
}


