package application.ui;


import java.util.List;
import java.util.Map;

import application.Item;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.scene.Scene;

public class FullChecklistScene
{
	public Scene mineFullCheck(Stage primaryStage) 
    {
        Item item = new Item();
        item.setGame("Minecraft");

        List<String> items = item.displayIDs();
        VBox layout = new VBox(10);

        for (String itemName : items) 
        {
            CheckBox itemCheckBox = new CheckBox(itemName);
            VBox rawMaterialsBox = new VBox(5);

            item.setID(itemName);
            Map<String, Integer> requiredMaterials = item.updatedRecipeQuantities();

            for (Map.Entry<String, Integer> entry : requiredMaterials.entrySet()) 
            {
                String materialName = entry.getKey();
                int requiredAmount = entry.getValue();

                Label materialLabel = new Label(materialName);

                Spinner<Integer> quantitySpinner = new Spinner<>();
                quantitySpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, requiredAmount, requiredAmount));
                quantitySpinner.setPrefWidth(80);

                // Strike through raw material when spinner reaches 0
                quantitySpinner.valueProperty().addListener((obs, oldValue, newValue) -> 
                {
                    if (newValue == 0) 
                        materialLabel.setStyle("-fx-strikethrough: true;");
                    else 
                        materialLabel.setStyle("-fx-strikethrough: false;");
                });

                // Make sure users can't type illegal values
                quantitySpinner.focusedProperty().addListener((obs, wasFocused, isNowFocused) -> 
                {
                    if (!isNowFocused) 
                    {
                        try 
                        {
                            int value = Integer.parseInt(quantitySpinner.getEditor().getText());
                            if (value > requiredAmount) 
                            {
                                quantitySpinner.getValueFactory().setValue(requiredAmount);
                            } 
                            else if (value < 0) 
                            {
                            	quantitySpinner.getValueFactory().setValue(0);
                            }
                        }
                        
                        catch (NumberFormatException e) 
                        {
                            quantitySpinner.getValueFactory().setValue(requiredAmount);
                        }
                    }
                });
                HBox materialRow = new HBox(10, materialLabel, quantitySpinner);
                rawMaterialsBox.getChildren().add(materialRow);

            }

            VBox itemBox = new VBox(10, itemCheckBox, rawMaterialsBox);
            itemBox.setPadding(new Insets(10));
            itemBox.setStyle("-fx-border-color: gray; -fx-border-width: 1; -fx-border-radius: 5;");

            layout.getChildren().add(itemBox);
        }

        ScrollPane scrollPane = new ScrollPane(layout);
        scrollPane.setFitToWidth(true);

        return new Scene(scrollPane, 600, 400);
    }

	//Scene 1B -- Stardew Valley FULL Checklist
    public Scene stardewFullCheck(Stage primaryStage) 
    {
        // Default values
    	Item item = new Item();
        item.setGame("Stardew Valley");

        //List of items
        List<String> items = item.displayIDs();
        VBox layout = new VBox(10);

        //For each item in the list, perform the following code
        for (String itemName : items) 
        {
            CheckBox itemCheckBox = new CheckBox(itemName);
            VBox rawMaterialsBox = new VBox(5);

            item.setID(itemName);
            Map<String, Integer> requiredMaterials = item.updatedRecipeQuantities();

            for (Map.Entry<String, Integer> entry : requiredMaterials.entrySet()) 
            {
            	Item newItem = new Item();
            	String materialName = entry.getKey();
                int requiredAmount = entry.getValue();

                Label materialLabel = new Label(materialName);

                Spinner<Integer> quantitySpinner = new Spinner<>();
                quantitySpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, requiredAmount, requiredAmount));
                quantitySpinner.setPrefWidth(80);

                quantitySpinner.valueProperty().addListener((obs, oldValue, newValue) -> 
                {
                    if (newValue == 0) 
                        materialLabel.setStyle("-fx-strikethrough: true;");
                    else 
                        materialLabel.setStyle("-fx-strikethrough: false;");
                });

                HBox materialRow = new HBox(10, materialLabel, quantitySpinner);
                rawMaterialsBox.getChildren().add(materialRow);
            }

            VBox itemBox = new VBox(10, itemCheckBox, rawMaterialsBox);
            itemBox.setPadding(new Insets(10));
            itemBox.setStyle("-fx-border-color: gray; -fx-border-width: 1; -fx-border-radius: 5;");

            layout.getChildren().add(itemBox);
        }

        ScrollPane scrollPane = new ScrollPane(layout);
        scrollPane.setFitToWidth(true);

        return new Scene(scrollPane, 600, 400);
    }
}


