// MainUI.java
package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application 
{
    @Override
    public void start(Stage primaryStage) 
    {
        primaryStage.setTitle("Material Farming Checklist");

        VBox layout = createGameSelector(primaryStage);
        Scene scene = new Scene(layout, 600, 400);
        scene.getStylesheets().add(getClass().getResource("/application/resources/application.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private VBox createGameSelector(Stage primaryStage) 
    {
        ComboBox<String> gameSelectionDrop = new ComboBox<>();
        gameSelectionDrop.getItems().addAll("Minecraft", "Stardew Valley");
        gameSelectionDrop.setPromptText("Select a game");

        Button createListButton = new Button("Create List");
        createListButton.setOnAction(e -> 
        {
            String selectedGame = gameSelectionDrop.getValue();
            if ("Minecraft".equals(selectedGame)) 
            {
                SceneController.switchToMineScene(primaryStage);
            } 
            
            else if ("Stardew Valley".equals(selectedGame)) 
            {
                SceneController.switchToStardewScene(primaryStage);
            }
        });

        VBox layout = new VBox(20);
        layout.getChildren().addAll(gameSelectionDrop, createListButton);
        layout.setStyle("-fx-padding: 20;");

        return layout;
    }

    public static void main(String[] args) 
    {
        launch(args);
    }
}