// ui/ChecklistManager.java
package application;

import java.util.HashMap;

public class ChecklistManager 
{
    private static final HashMap<String, Integer> minecraftChecklist = new HashMap<>();
    private static final HashMap<String, Integer> stardewChecklist = new HashMap<>();

    public static HashMap<String, Integer> getMinecraftChecklist() 
    {
        return minecraftChecklist;
    }

    public static HashMap<String, Integer> getStardewChecklist() 
    {
        return stardewChecklist;
    }

    public static void addItem(String game, String item, int quantity) 
    {
        HashMap<String, Integer> list = game.equals("Minecraft") ? minecraftChecklist : stardewChecklist;
        list.put(item, quantity);
    }

    public static void removeItem(String game, String item) 
    {
        if (game.equals("Minecraft")) {
            minecraftChecklist.remove(item);
        } else {
            stardewChecklist.remove(item);
        }
    }
}
	