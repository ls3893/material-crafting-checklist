package application.ui;

import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.util.HashMap;
import java.util.Map;

public class CraftingChecklistItem extends VBox 
{
    private final String itemName;
    private final Map<String, Integer> requiredMaterials;
    private final Map<String, HBox> materialRows = new HashMap<>();

    public CraftingChecklistItem(String itemName, Map<String, Integer> requiredMaterials) 
    {
        this.itemName = itemName;
        this.requiredMaterials = requiredMaterials;

        Label title = new Label("Item: " + itemName);
        getChildren().add(title);

        for (Map.Entry<String, Integer> entry : requiredMaterials.entrySet()) {
            String material = entry.getKey();
            int quantity = entry.getValue();

            Label label = new Label(material + " x" + quantity);
            HBox row = new HBox(5);
            row.getChildren().add(label);

            for (int i = 0; i < quantity; i++) {
                CheckBox checkBox = new CheckBox();
                row.getChildren().add(checkBox);
            }

            materialRows.put(material, row);
            getChildren().add(row);
        }

        setSpacing(10);
        setStyle("-fx-padding: 10; -fx-border-color: #ccc; -fx-border-width: 1;");
    }

    public boolean isComplete() {
        return materialRows.values().stream()
                .allMatch(row -> row.getChildren().stream()
                        .filter(node -> node instanceof CheckBox)
                        .allMatch(node -> ((CheckBox) node).isSelected()));
    }
}
