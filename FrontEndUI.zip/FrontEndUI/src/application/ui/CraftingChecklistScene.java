package application.ui;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.HashMap;
import java.util.Map;

import application.SceneController;

public class CraftingChecklistScene 
{

    public Scene createScene(Stage primaryStage) {
        Map<String, Integer> ironSwordRecipe = new HashMap<>();
        ironSwordRecipe.put("Iron Ingot", 6);
        ironSwordRecipe.put("Stick", 2);

        CraftingChecklistItem checklistItem = new CraftingChecklistItem("Iron Sword", ironSwordRecipe);

        
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> SceneController.switchToMainMenu(primaryStage));

        VBox layout = new VBox(20, checklistItem, backButton);
        layout.setStyle("-fx-padding: 20;");

        return new Scene(layout, 600, 400);
    }
}
