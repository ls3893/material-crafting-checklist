// ui/StardewScene.java
package application.ui;

import application.ChecklistManager;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class StardewScene 
{
    public Scene createStardewScene(Stage primaryStage) 
    {
        ComboBox<String> category = new ComboBox<>();
        category.getItems().addAll("Bombs", "Furniture"); //replace with csv
        category.setPromptText("Category: "); //replace with csv
        
        //note: category CHANGES what items show
        
        ComboBox<String> item = new ComboBox<>();
        item.getItems().addAll("Bombs", "Furniture"); //replace with csv
        item.setPromptText("Item: "); //replace with csv

        Spinner<Integer> quantitySpinner = new Spinner<>();
        quantitySpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 100, 1));

        Button addButton = new Button("Add to Checklist");
        addButton.setOnAction(e -> 
        {
            String selectedMaterial = category.getValue();
            int quantity = quantitySpinner.getValue();
            if (selectedMaterial != null) {
                ChecklistManager.addItem("Stardew Valley", selectedMaterial, quantity);
            }
        });

        Button viewChecklistButton = new Button("View Checklist");
        viewChecklistButton.setOnAction(e -> {
            ChecklistViewer.viewGameChecklists("Stardew Valley", ChecklistManager.getStardewChecklist());
        });

        GridPane layout = new GridPane();
        layout.setVgap(10);
        layout.setHgap(10);
        layout.setPadding(new Insets(20));

        
        layout.add(new Label("Item:"), 0, 0);
        layout.add(item, 1, 0);
        layout.add(new Label("Quantity:"), 1, 1);
        layout.add(quantitySpinner, 2, 1);
        layout.add(addButton, 0, 2);
        layout.add(viewChecklistButton, 1, 2);

        return new Scene(layout, 600, 400);
    }
}