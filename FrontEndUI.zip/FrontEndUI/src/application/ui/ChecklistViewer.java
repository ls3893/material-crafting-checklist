// ui/ChecklistViewer.java
package application.ui;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.HashMap;
public class ChecklistViewer 
{
    public static void viewGameChecklists(String game, HashMap<String, Integer> checklist) 
    {
        Stage viewChecklist = new Stage();
        viewChecklist.setTitle(game + " Checklist");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        if (checklist.isEmpty()) 
        {
            layout.getChildren().add(new Label("No items in checklist."));
        } 
        else 
        {
            checklist.forEach((item, qty) -> 
            {
                layout.getChildren().add(new Label(item + ": " + qty));
            });
        }

        Button closeButton = new Button("Close");
        closeButton.setOnAction(e -> viewChecklist.close());
        layout.getChildren().add(closeButton);

        Scene scene = new Scene(layout, 300, 400);
        viewChecklist.setScene(scene);
        viewChecklist.showAndWait();
    }
}