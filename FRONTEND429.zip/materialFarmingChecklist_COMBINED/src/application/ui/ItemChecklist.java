package application.ui;

import java.util.List;
import java.util.Map;

import application.Item;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ItemChecklist {

	public Scene mineItemCheck(Stage primaryStage) 
	{
	    VBox layout = new VBox(10);
	    layout.setStyle("-fx-background-color: #9DB496;");
	    List<Item> items = ChecklistSelection.customMinecraftItems;

	    if (!items.isEmpty()) 
	    {
	        Item customItem = items.get(items.size() - 1); // most recent

	        Text mineTitle = new Text("Craft: " + customItem.getID());
	        mineTitle.setId("subheader");

	        CheckBox itemCheckBox = new CheckBox(customItem.getID());
	        VBox rawMaterialsBox = new VBox(10);

	        Map<String, Integer> requiredMaterials = customItem.updatedRecipeQuantities();

	        for (Map.Entry<String, Integer> entry : requiredMaterials.entrySet()) 
	        {
	            String materialName = entry.getKey();
	            int requiredAmount = entry.getValue();

	            Text materialText = new Text(materialName);
	            materialText.getStyleClass().add("text");

	            Spinner<Integer> quantitySpinner = new Spinner<>();
	            quantitySpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, requiredAmount, requiredAmount));
	            quantitySpinner.setPrefWidth(115);

	            quantitySpinner.valueProperty().addListener((obs, oldValue, newValue) -> 
	            {
	                materialText.setStrikethrough(newValue == 0);
	            });

	            HBox materialRow = new HBox(10, materialText, quantitySpinner);
	            rawMaterialsBox.getChildren().add(materialRow);
	        }

	        VBox itemBox = new VBox(10, mineTitle, itemCheckBox, rawMaterialsBox);
	        itemBox.setPadding(new Insets(10));
	        itemBox.setStyle("-fx-border-color: gray; -fx-border-width: 1; -fx-border-radius: 5;");
	        layout.getChildren().add(itemBox);
	    }

	    Button toChecklistSelect = new Button("View Checklists");
	    toChecklistSelect.setOnAction(e -> {
	        Scene nextScene = new ChecklistSelection().chooseGameList(primaryStage);
	        primaryStage.setScene(nextScene);
	    });

	    HBox toChecklistButton = new HBox(toChecklistSelect);
	    toChecklistButton.setPadding(new Insets(10));
	    layout.getChildren().add(toChecklistButton);

	    ScrollPane scrollPane = new ScrollPane(layout);
	    scrollPane.setFitToWidth(true);
	    scrollPane.setFitToHeight(true);
	    layout.setFillWidth(true);
	    scrollPane.getStyleClass().add("root");

	    Scene scene = new Scene(scrollPane, 600, 400);
	    scrollPane.setStyle("-fx-background-color: #9DB496;");
	    scene.getStylesheets().add(AddItemScene.class.getResource("/application/resources/application.css").toExternalForm());

	    return scene;
	}


	public Scene stardewItemCheck(Stage primaryStage) 
	{
	    VBox layout = new VBox(10);
	    layout.setStyle("-fx-background-color: #9DB496;");
	    List<Item> items = ChecklistSelection.customStardewItems;

	    if (!items.isEmpty())
	    {
	        Item customItem = items.get(items.size() - 1); // most recent

	        Label stardewTitle = new Label("Craft: " + customItem.getID());
	        stardewTitle.setId("header");

	        CheckBox itemCheckBox = new CheckBox(customItem.getID());
	        VBox rawMaterialsBox = new VBox(5);

	        String recipeSource = customItem.getRecipeSource();
	        CheckBox sourceCheck = new CheckBox("Requires " + recipeSource);
	        sourceCheck.setStyle("-fx-padding: 0 0 5 0;");
	        sourceCheck.setId("subheader");

	        Map<String, Integer> requiredMaterials = customItem.updatedRecipeQuantities();

	        for (Map.Entry<String, Integer> entry : requiredMaterials.entrySet()) 
	        {
	            String materialName = entry.getKey();
	            int requiredAmount = entry.getValue();

	            Text materialText = new Text(materialName);
	            materialText.getStyleClass().add("text");

	            Spinner<Integer> quantitySpinner = new Spinner<>();
	            quantitySpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, requiredAmount, requiredAmount));
	            quantitySpinner.setPrefWidth(100);

	            quantitySpinner.valueProperty().addListener((obs, oldValue, newValue) ->
	            {
	                materialText.setStrikethrough(newValue == 0);
	            });

	            HBox materialRow = new HBox(10, materialText, quantitySpinner);
	            rawMaterialsBox.getChildren().add(materialRow);
	        }

	        VBox itemBox = new VBox(10, stardewTitle, itemCheckBox, rawMaterialsBox, sourceCheck);
	        layout.getChildren().add(itemBox);
	    }

	    Button toChecklistSelect = new Button("View Checklists");
	    toChecklistSelect.setOnAction(e -> {
	        Scene nextScene = new ChecklistSelection().chooseGameList(primaryStage);
	        primaryStage.setScene(nextScene);
	    });

	    HBox toChecklistButton = new HBox(toChecklistSelect);
	    layout.getChildren().add(toChecklistButton);

	    ScrollPane scrollPane = new ScrollPane(layout);
	    scrollPane.setFitToWidth(true);
	    scrollPane.setFitToHeight(true);
	    layout.setFillWidth(true);
	    scrollPane.getStyleClass().add("root");

	    Scene scene = new Scene(scrollPane, 800, 600);
	    scene.getStylesheets().add(AddItemScene.class.getResource("/application/resources/application.css").toExternalForm());

	    return scene;
	}
}