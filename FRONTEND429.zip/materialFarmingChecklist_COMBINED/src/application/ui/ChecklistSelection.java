package application.ui;

import java.util.ArrayList;
import java.util.List;

import application.Item;
import application.ui.ItemChecklist;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class ChecklistSelection
{
	public static List<Item> customMinecraftItems = new ArrayList<>();
	public static List<Item> customStardewItems = new ArrayList<>();
	

	//Scene #3 -- Which Game Checklist does the user want to see?
	public Scene chooseGameList(Stage primaryStage) 
	{
	    Text gameListTitle = new Text("Select a Game Checklist");
	    gameListTitle.setFont(Font.font("System", FontWeight.BOLD, 34));
	    gameListTitle.setFill(javafx.scene.paint.Color.web("#f8f2e8"));
	    gameListTitle.setTextAlignment(TextAlignment.CENTER);

	    // RadioButtons
	    RadioButton mineListChoice = new RadioButton("Minecraft");
	    RadioButton stardewListChoice = new RadioButton("Stardew Valley");
	    ToggleGroup listChoices = new ToggleGroup();

	    // Add to ToggleGroup (Only can select one)
	    mineListChoice.setToggleGroup(listChoices);
	    stardewListChoice.setToggleGroup(listChoices);

	    // Button to move on to individual game checklists
	    Button button = new Button("View Game Checklist");
	    button.setOnAction(e -> 
	    {
	        RadioButton selectedButton = (RadioButton) listChoices.getSelectedToggle();
	        if (selectedButton != null) 
	        {
	        	String selectedGame = selectedButton.getText();
	        	if (selectedGame.equals("Minecraft")) 
	        	{
	        	    FullChecklistScene mineFullCheck = new FullChecklistScene();
	        	    primaryStage.setScene(mineFullCheck.mineFullCheck(primaryStage));
	        	} 
	        	else if (selectedGame.equals("Stardew Valley")) 
	        	{
	        	    FullChecklistScene stardewFullCheck = new FullChecklistScene();
	        	    primaryStage.setScene(stardewFullCheck.stardewFullCheck(primaryStage));
	        	}

	        }
	    });
	
	    VBox layout = new VBox(10); // spacing of 10 between elements
	    layout.setAlignment(Pos.CENTER);
	    layout.getChildren().addAll(gameListTitle, mineListChoice, stardewListChoice, button);
	    
	    Scene chooseGameListScene = new Scene(layout, 800, 600);
	    chooseGameListScene.getStylesheets().add(application.ui.AddItemScene.class.getResource("/application/resources/application.css").toExternalForm());
	    return chooseGameListScene;
	}
}
