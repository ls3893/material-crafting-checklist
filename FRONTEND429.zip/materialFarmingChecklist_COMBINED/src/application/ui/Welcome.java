package application.ui;

import java.util.Arrays;
import application.MusicPlayer;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;

public class Welcome
{
    private MediaPlayer backgroundMusic;

    public Scene welcomeScene(Stage primaryStage)
    {
        MusicPlayer.stopMusic();

        Text welcome = new Text("Welcome to Material Farming Checklist");
        welcome.setFont(Font.font("System", FontWeight.BOLD, 34));
        welcome.setFill(javafx.scene.paint.Color.web("#f8f2e8"));
        welcome.setTextAlignment(TextAlignment.CENTER);
        VBox gameSelectorSet = createGameSelector(primaryStage);

        VBox layout1 = new VBox(30);
        layout1.getChildren().addAll(welcome, gameSelectorSet);
        layout1.setAlignment(Pos.CENTER);

        Scene scene = new Scene(layout1, 600, 400);
        scene.getStylesheets().add(getClass().getResource("/application/resources/application.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();
        return scene;
    }

    public VBox createGameSelector(Stage primaryStage) 
    {
        Label caption = new Label("let cozy games be cozy");
        caption.setId("caption");

        ComboBox<String> gameSelectionDrop = new ComboBox<>();
        gameSelectionDrop.setId("combo-box");
        gameSelectionDrop.getItems().addAll("Minecraft", "Stardew Valley");
        gameSelectionDrop.setPromptText("Select a game");

        Button chooseItemButton = new Button("Choose Item");
        chooseItemButton.setId("button");

        chooseItemButton.setOnAction(e -> 
        {
            String gameChoice = gameSelectionDrop.getValue();
            if (gameChoice == null) return;

            String musicPath = "";
            String cssPath = "";
            AddItemScene addItemScene = new AddItemScene();

            if ("Minecraft".equals(gameChoice)) 
            {
            	cssPath = "/application/resources/mineStyle.css";
            	musicPath = "/application/resources/minecraft.mp3";
            } 
            else if ("Stardew Valley".equals(gameChoice)) 
            {
                cssPath = "/application/resources/stardewStyle.css";
            	musicPath = "/application/resources/stardew.mp3";
            }

            MusicPlayer.playMusic(musicPath);

            if ("Minecraft".equals(gameChoice)) 
            {
                Scene scene2a = addItemScene.createAddItemScene(
                    primaryStage,
                    "Minecraft",
                    Arrays.asList("Basic", "Block", "Tool", "Defense", "Mechanism", "Food", "Other", "Dye", "Wool", "Brewing"),
                    cssPath,
                    musicPath
                );
                primaryStage.setScene(scene2a);
            } 
            else if ("Stardew Valley".equals(gameChoice))
            {
                Scene scene2b = addItemScene.createAddItemScene(
                    primaryStage,
                    "Stardew Valley",
                    Arrays.asList("Bombs", "Fences", "Sprinklers", "Artisan Equipment", "Fertilizer", "Seeds", "Decor", "Fishing", "Rings", "Edible Items", "Consumables", "Lighting", "Refining Equipment", "Furniture", "Storage Equipment", "Signs", "Misc"),
                    cssPath,
                    musicPath
                );
                primaryStage.setScene(scene2b);
            }
        });

        VBox layout = new VBox(10);
        layout.getChildren().addAll(caption, gameSelectionDrop, chooseItemButton);
        layout.setAlignment(Pos.CENTER);

        return layout;
    }
}



