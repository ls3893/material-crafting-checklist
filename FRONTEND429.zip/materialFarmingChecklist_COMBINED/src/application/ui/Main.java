package application.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import application.Item;
import application.ui.Welcome;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application 
{
 //Stage #1 -- start => minecraft/stardew valley
	@Override
    public void start(Stage primaryStage) 
    {
    
        primaryStage.setTitle("Material Farming Checklist");
    
        
    //Scene #1 -- Welcome! and Game Selection

        Welcome welcomeScreen = new Welcome();
        Scene scene1 = welcomeScreen.welcomeScene(primaryStage);
        
        primaryStage.setScene(scene1);
        primaryStage.show();
           
    }

	public static void main(String[] args) 
    {
        launch(args);
    }
    
}

