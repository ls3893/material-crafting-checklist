package application.ui;

import application.Item;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class FullChecklistScene {

    public Scene mineFullCheck(Stage primaryStage) 
    {
        return createChecklistScene(primaryStage, "Minecraft", ChecklistSelection.customMinecraftItems);
    }

    public Scene stardewFullCheck(Stage primaryStage) 
    {
        return createChecklistScene(primaryStage, "Stardew Valley", ChecklistSelection.customStardewItems);
    }

    private Scene createChecklistScene(Stage primaryStage, String gameName, List<Item> itemList) 
    {
        
    	VBox root = new VBox(15);
        root.setPadding(new Insets(20));

        ScrollPane scrollPane = new ScrollPane(root);
        scrollPane.setFitToWidth(true);

        Text gameFullCheck = new Text("Full Checklist: " + gameName);
        gameFullCheck.setFont(Font.font("System", FontWeight.BOLD, 34));
        gameFullCheck.setFill(javafx.scene.paint.Color.web("#f8f2e8"));
        gameFullCheck.setTextAlignment(TextAlignment.CENTER);
        root.getChildren().add(gameFullCheck);

        VBox itemsBox = new VBox(15);

        for (Item item : itemList) 
        {
            VBox itemBox = new VBox(10);
            itemBox.setPadding(new Insets(10));
            itemBox.setStyle("-fx-border-color: gray; -fx-border-radius: 5; -fx-border-width: 1;");

            CheckBox itemCheck = new CheckBox(item.getID());
            itemCheck.setStyle("-fx-font-weight: bold;");

            VBox materialsBox = new VBox(5);
            Map<String, Integer> materials = item.updatedRecipeQuantities();
            for (Map.Entry<String, Integer> entry : materials.entrySet()) 
            {
                String material = entry.getKey();
                int amount = entry.getValue();

                Text materialText = new Text(material);
                Spinner<Integer> spinner = new Spinner<>(0, amount, amount);
                spinner.setPrefWidth(115);

                spinner.valueProperty().addListener((obs, oldVal, newVal) -> 
                {
                    materialText.setStrikethrough(newVal == 0);
                });

                HBox materialRow = new HBox(10, materialText, spinner);
                materialsBox.getChildren().add(materialRow);
            }

            if (gameName.equals("Stardew Valley")) 
            {
                CheckBox recipeSourceCheck = new CheckBox("Requires: " + item.getRecipeSource());
                recipeSourceCheck.setSelected(false);
                itemBox.getChildren().addAll(itemCheck, recipeSourceCheck, materialsBox);
            } else {
                itemBox.getChildren().addAll(itemCheck, materialsBox);
            }

            itemBox.setUserData(itemCheck); 
            itemsBox.getChildren().add(itemBox);
        }

        root.getChildren().add(itemsBox);

        HBox buttonBar = new HBox(10);

        Button newItemButton = new Button("New Item");
        newItemButton.setOnAction(e -> 
        {
            primaryStage.setScene(new Welcome().welcomeScene(primaryStage));
        });

        Button removeItemButton = new Button("Remove Item");
        removeItemButton.setOnAction(e -> 
        {
            Iterator<Item> iterator = itemList.iterator();
            for (int i = 0; i < itemsBox.getChildren().size(); i++) 
            {
                VBox itemBox = (VBox) itemsBox.getChildren().get(i);
                CheckBox check = (CheckBox) itemBox.getUserData();
                if (check.isSelected()) 
                {
                    itemsBox.getChildren().remove(i);
                    iterator.next();
                    iterator.remove();
                    i--;
                } else {
                    iterator.next();
                }
            }
        });

        buttonBar.getChildren().addAll(newItemButton, removeItemButton);
        root.getChildren().add(buttonBar);

        Scene scene = new Scene(scrollPane, 800, 600);
        root.setStyle("-fx-background-color: #9DB496;");
        scene.getStylesheets().add(getClass().getResource("/application/resources/application.css").toExternalForm());
        return scene;
    }
}





