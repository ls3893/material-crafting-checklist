package application.ui;

import java.util.List;

import application.Item;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AddItemScene
{
    private String musicPath; 

    public Scene createAddItemScene(Stage primaryStage, String gameName, List<String> categories, String cssFilePath, String musicPath)
    {
        this.musicPath = musicPath;  

        Item item = new Item();
        item.setGame(gameName);

        Label title = new Label(gameName + " Add Item");
        HBox titleForm = new HBox(title);
        titleForm.setAlignment(Pos.CENTER);
        titleForm.setId("header");

        Label categoryLabel = new Label("Category:");
        categoryLabel.setId("subheader");
        ComboBox<String> categoryDrop = new ComboBox<>();
        categoryDrop.getItems().addAll(categories);
        categoryDrop.setPromptText("Select one");
        

        Label itemLabel = new Label("Item:");
        itemLabel.setId("subheader");
        
        ComboBox<String> itemDrop = new ComboBox<>();
        itemDrop.setPromptText("Select one");
        
        Spinner<Integer> quantitySpin = new Spinner<>();
        quantitySpin.setPrefWidth(120);
        quantitySpin.setPrefHeight(40);

        quantitySpin.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 999, 1));

        Button addItemButton = new Button("Add Item");

        categoryDrop.setOnAction(e -> 
        {
            String selectedCategory = categoryDrop.getValue();
            item.setCategory(selectedCategory);
            itemDrop.getItems().clear();
            itemDrop.getItems().addAll(item.displayIDs());
        });

        itemDrop.setOnAction(e -> 
        {
            String selectedItem = itemDrop.getValue();
            item.setID(selectedItem);
        });

        addItemButton.setOnAction(e -> 
        {
            try 
            {
                int quantity = quantitySpin.getValue();
                if (quantity <= 0) return;

                Item newItem = new Item();
                newItem.setGame(gameName);
                newItem.setCategory(categoryDrop.getValue());
                newItem.setID(itemDrop.getValue());
                newItem.setQuantity(quantity);
                newItem.updatedRecipeQuantities();


                if ("Minecraft".equals(gameName)) 
                {
                    ChecklistSelection.customMinecraftItems.add(newItem); 
                    primaryStage.setScene(new ItemChecklist().mineItemCheck(primaryStage));
                } 
                else if ("Stardew Valley".equals(gameName)) 
                {
                    ChecklistSelection.customStardewItems.add(newItem); 
                    primaryStage.setScene(new ItemChecklist().stardewItemCheck(primaryStage));
                } 
            } 
            catch (NumberFormatException ex) 
            {
                System.out.println("Error: invalid quantity");
            }
        });

        HBox categoryForm = new HBox(10, categoryLabel, categoryDrop);
        HBox itemForm = new HBox(10, itemLabel, itemDrop, quantitySpin);
        HBox buttonForm = new HBox(addItemButton);
        buttonForm.setAlignment(Pos.CENTER);

        VBox layout = new VBox(15, titleForm, categoryForm, itemForm, buttonForm);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);

        
        StackPane root = new StackPane(layout);
        root.setPrefSize(800, 600);
        StackPane.setAlignment(layout, Pos.CENTER); 

        Scene scene = new Scene(root, 800, 600);
        scene.getStylesheets().add(application.ui.AddItemScene.class.getResource(cssFilePath).toExternalForm());
        return scene;
    }
}





