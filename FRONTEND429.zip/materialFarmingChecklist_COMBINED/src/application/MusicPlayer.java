package application;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

public class MusicPlayer {
    private static MediaPlayer mediaPlayer;

    public static void playMusic(String musicPath) {
        stopMusic(() -> { // fade out old music THEN start new
            try {
                java.net.URL resource = MusicPlayer.class.getResource(musicPath);
                if (resource != null) {
                    Media media = new Media(resource.toExternalForm());
                    mediaPlayer = new MediaPlayer(media);
                    mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
                    mediaPlayer.setVolume(0); // Start muted for fade-in
                    mediaPlayer.play();
                    fadeInMusic();
                } else {
                    System.out.println("Could not find music file: " + musicPath);
                }
            } catch (Exception e) 
            {
                e.printStackTrace();
            }
        });
    }

    public static void stopMusic() 
    {
        stopMusic(null);
    }

    private static void stopMusic(Runnable afterFadeOut) 
    {
        if (mediaPlayer != null) 
        {
            Timeline fadeOut = new Timeline(
                new KeyFrame(Duration.millis(100), e -> 
                {
                    double volume = mediaPlayer.getVolume();
                    mediaPlayer.setVolume(Math.max(0, volume - 0.05)); // decrease by 5%
                })
            );
            fadeOut.setCycleCount(20); 
            fadeOut.setOnFinished(e -> 
            {
                mediaPlayer.stop();
                mediaPlayer = null;
                if (afterFadeOut != null) 
                {
                    afterFadeOut.run();
                }
            });
            fadeOut.play();
        } 
        else 
        {
            if (afterFadeOut != null) 
            {
                afterFadeOut.run();
            }
        }
    }

    private static void fadeInMusic() 
    {
        if (mediaPlayer != null) 
        {
            Timeline fadeIn = new Timeline(
                new KeyFrame(Duration.millis(100), e -> 
                {
                    double volume = mediaPlayer.getVolume();
                    mediaPlayer.setVolume(Math.min(1.0, volume + 0.05)); 
                })
            );
            fadeIn.setCycleCount(20); 
            fadeIn.play();
        }
    }
}


